#include "mydbus.h"

MyDbus::MyDbus(QObject *parent) :
    QObject(parent) , view(NULL)
{
}

bool MyDbus::checkDbus(){
    if (!QDBusConnection::sessionBus().isConnected()) {
        qDebug() << "Cannot connect to the D-Bus session bus.";
        return false;
    }
    return true;
}

bool MyDbus::registerService(){
    if(!QDBusConnection::sessionBus().registerService(SERVICE_NAME)){
        qDebug() << qPrintable(QDBusConnection::sessionBus().lastError().message());
        return false;
    }

    if(!QDBusConnection::sessionBus().registerObject("/", this, QDBusConnection::ExportAllSlots)){
        qDebug() << qPrintable(QDBusConnection::sessionBus().lastError().message());
        return false;
    }

    return true;
}

bool MyDbus::isInstanceRunning(){
    QDBusInterface iface(SERVICE_NAME, "/", "", QDBusConnection::sessionBus());
    if (iface.isValid()) {
        QDBusReply<QString> reply = iface.call("ping");
        if (reply.isValid()) {
            qDebug() << "Reply was: ", qPrintable(reply.value());
            return true;
        }

        qDebug() << "Call failed: " << qPrintable(reply.error().message());
        return false;
    }else{
        qDebug() << "invalid iface";
        return false;
    }

    qDebug() << qPrintable(QDBusConnection::sessionBus().lastError().message());

    return true;
}

QString MyDbus::ping(void){
    qDebug() << "Me llaman";
    if(view)
        view->showFullScreen();
    qDebug() << "No explote";
    return "existo!";
}

void MyDbus::setView(QQuickView* view){
    this->view = view;
}
