#ifndef MYDBUS_H
#define MYDBUS_H

#include <sailfishapp.h>

#include <QObject>
#include <QDebug>
#include <QtDBus/QDBusConnection>
#include <QtDBus/QDBusInterface>
#include <QtDBus/QDBusReply>

#define SERVICE_NAME "harbour.boxapp.client"

class MyDbus : public QObject
{
    Q_OBJECT
public:
    explicit MyDbus(QObject *parent = 0);
    bool checkDbus();
    bool registerService();
    bool isInstanceRunning();
    void setView(QQuickView* view);

signals:

public slots:
    Q_SCRIPTABLE QString ping(void);

protected:
    QQuickView* view;
};

#endif // MYDBUS_H
