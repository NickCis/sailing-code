#include "mytimer.h"
#include <QDebug>

MyTimer::MyTimer(QObject *parent) :
    QTimer(parent),
    counter(0)
{
    connect(this, SIGNAL(timeout()), this, SLOT(update()));
    this->start(3000);
}

void MyTimer::update(){
    qDebug() << "Running " << (this->counter++);
}
