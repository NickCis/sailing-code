In order to install this example, you must login to the SailfishOS emulator as root and run the following commands

    chmod +x example-service.py
    install example-service.py /usr/bin
    install harbour.buatsap.Service.service /usr/share/dbus-1/services/

These commands give the `example-service.py` file executable permission, install the file under `/usr/bin` and isntall the `.service` file in `/usr/share/dbus-1/services`
